<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function isValidName($name) {
    return preg_match('/^[a-zA-Z]+$/', $name);
}

function isValidPhoneNumber($phone) {
    return preg_match('/^[0-9]+$/', $phone);
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

$firstname = $conn->real_escape_string($_POST['firstname']);
$middlename = $conn->real_escape_string($_POST['middlename']);
$lastname = $conn->real_escape_string($_POST['lastname']);
$email = $conn->real_escape_string($_POST['email']);
$password = $conn->real_escape_string($_POST['password']);
$confirm_password = $conn->real_escape_string($_POST['confirm_password']);
$phone = $conn->real_escape_string($_POST['phone']);

if (!isValidName($firstname) || !isValidName($middlename) || !isValidName($lastname)) {
    $_SESSION['error'] = "First name, middle name, and last name should only contain letters";
}

if (!isValidPhoneNumber($phone)) {
    $_SESSION['error'] = "Phone number should contain only numbers";
}

if (!isValidEmail($email)) {
    $_SESSION['error'] = "Invalid email format";
}

if ($password !== $confirm_password) {
    $_SESSION['error'] = "The password does not match the confirm password";
}

$query = "SELECT email FROM users WHERE email = '$email'";
$result = $conn->query($query);

if ($result === false) {
    $_SESSION['error'] = "Database error: " . $conn->error;
} else {
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Email already in use";
    }
}

if (isset($_SESSION['error'])) {
    header("Location: test.php?error=" . urlencode($_SESSION['error']));
    exit;
}
$_SESSION['firstname']=$firstname; 
$_SESSION['middlename']=$middlename;
$_SESSION['lastname']=$lastname;
$_SESSION['email']=$email;
$_SESSION['password']=$password;
$_SESSION['phone']=$phone;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function generateVerificationCode() {
    return str_pad(mt_rand(0, 9999), 4, '0', STR_PAD_LEFT);
}

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $verificationCode = generateVerificationCode();
    $_SESSION['verification_code'] = $verificationCode;

    $subject = 'Verification Code';
    $message = 'Your verification code is: ' . $verificationCode;

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'hasanakil2003@gmail.com';
        $mail->Password = 'dzdcuhmhlcxxgvuu';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('hasanakil2003@gmail.com');
        $mail->addAddress($email);
        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->send();
    } catch (Exception $e) {
        echo "Error: Unable to send verification email. {$mail->ErrorInfo}";
    }
} else {
    echo "Error: Email or password not provided.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Verification Form</title>
    <style>
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
        }

        .input-group input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .input-group input[type="submit"] {
            background-color: #4caf50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .input-group input[type="submit"]:hover {
            background-color: #45a049;
        }

        .alert {
            padding: 15px;
            background-color: #f44336;
            color: white;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verification</h2>
        <form id="verificationForm">
            <div class="input-group">
                <label for="verification_code">Enter Verification Code</label>
                <input type="text" id="verification_code" name="verification_code" required />
            </div>
            <div class="input-group">
                <input type="submit" value="Submit Verification" id="submitButton" />
            </div>
        </form>
        <div id="timer">Time remaining: <span id="time">02:00</span></div>
    </div>

    <script>
        var timer = 120; 
        var timerInterval;

        function startTimer() {
            var minutes, seconds;
            timerInterval = setInterval(function() {
                minutes = Math.floor(timer / 60);
                seconds = timer % 60;
                document.getElementById("time").textContent = (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
                timer--;
                if (timer < 0) {
                    clearInterval(timerInterval);
                    document.getElementById("time").textContent = "Time's up!";
                    document.getElementById("submitButton").disabled = true;
                }
            }, 1000);
        }

        startTimer();

        document.getElementById("verificationForm").addEventListener("submit", function(event) {
            event.preventDefault();

            var verificationCode = document.getElementById("verification_code").value;
            var formData = new FormData(document.getElementById("verificationForm"));
            formData.append("verification_code", verificationCode);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "verify.php", true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        alert("Verification successful! Proceeding to login page...");
                        window.location.href = "LogIn2.php";
                    } else {
                        alert("Incorrect verification code. Please try again.");
                    }
                } else {
                    alert("An error occurred during verification. Please try again.");
                }
            };
            xhr.send(formData);
        });
    </script>
</body>
</html>
