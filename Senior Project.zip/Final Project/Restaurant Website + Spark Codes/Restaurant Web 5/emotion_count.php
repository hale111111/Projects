<?php

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "spark";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    $happy_count = $data['happy'];
    $sad_count = $data['sad'];
    $angry_count = $data['angry'];
    $neutral_count = $data['neutral'];
    $fear_count = $data['fear'];
    $surprise_count = $data['surprise'];
    $disgust_count = $data['disgust'];
    
    $sql = "INSERT INTO emotion_counts (happy_count, sad_count,angry_count,neutral_count,fear_count,disgust_count,surprise_count) VALUES ($happy_count, $sad_count
    , $angry_count, $neutral_count, $fear_count, $disgust_count, $surprise_count)";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "No data received";
}

$conn->close();
?>
