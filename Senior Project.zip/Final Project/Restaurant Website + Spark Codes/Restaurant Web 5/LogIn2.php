<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>
    <link rel="stylesheet" href="LogIn.css" />
  </head>
  <body>
    <div class="container">
      <h1>Login</h1>

      <?php
      if(isset($_GET['error'])) {
          $error = $_GET['error'];
          if($error === 'failure') {
              echo "<p class='error-message'>Login failed. Please check your email and password.</p>";
          } elseif($error === 'success') {
              echo "<p class='success-message'>Login successful!</p>";
          }
      }
      ?>

      <form id="login-form" action="LogIn.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required />

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required />

        <button type="submit">Login</button>
      </form>
    </div>
  </body>
</html>
