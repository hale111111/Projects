<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$form_username = $_POST['username'];
$form_password = $_POST['password'];

$form_username = $conn->real_escape_string($form_username);
$form_password = $conn->real_escape_string($form_password);

$sql = "SELECT * FROM admin WHERE username = '$form_username' AND password = '$form_password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['admin_logged_in'] = true;
    header("Location: admin-page.php");
} else {
    echo "Invalid username or password";
}

$conn->close();
?>
