<?php

header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "spark";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the latest data from the database
$sql = "SELECT average_age, created_at FROM age_average ORDER BY created_at DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    $data = ["average_age" => 0, "created_at" => "N/A"];
}

$conn->close();

echo json_encode($data);
?>
