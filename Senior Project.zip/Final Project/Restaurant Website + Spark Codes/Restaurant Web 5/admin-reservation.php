<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: Admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
    
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
        }
        input, select {
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Fetch Reservations</h1>
        <form action="admin-reservation-get.php" method="post">


            <label for="user_id">User ID:</label>
            <input type="text" id="user_id" name="user_id">

            <label for="name">Name:</label>
            <input type="text" id="name" name="name">

            <label for="date">Date:</label>
            <input type="date" id="date" name="date">

            <label for="time">Time:</label>
            <input type="time" id="time" name="time">

            <label for="guests">Number of Guests:</label>
            <input type="number" id="guests" name="guests">

            <label for="table_type">Table Type:</label>
            <select id="table_type" name="table_type">
                <option value="">Select Table Type</option>
                <option value="indoor">Indoor</option>
                <option value="private">Private</option>
                <option value="outdoor">Outdoor</option>
            </select>

            <button type="submit">Fetch Reservations</button>
        </form>
    </div>
</body>
</html>
