<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restaurant Delivery</title>
    <link rel="stylesheet" href="delivery.css" />
  </head>
  <body>
  <script>
window.onload = function() {
    <?php
    session_start();

    if(!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
        echo 'document.getElementById("overlay").style.display = "block";';
    }
    ?>
}
</script>

<div id="overlay" style="display: none;">
    <div id="popup-form">
        <form action="Sign.html" method="post">
            <h2>Please Sign In or Log In</h2>
            <input type="submit" value="Sign In">
        </form>
        <form action="LogIn2.php">
            <input type="submit" value="Log In">
        </form>
    </div>
</div>
    
    <div class="container">
      <h1>Delivery</h1>
      <a href="GetDelivery.php" class="my-delivery-button">MyDelivery</a>
      <label for="address">Delivery Address:</label>
        <button class='button' onclick="getLocation()">Get Location</button>
    <div id="mapLink"></div>
    <div>
    <span id="latitude"></span></p> 
     <span id="longitude"></span></p> 
  </div>
      <form id="delivery-form" method="POST" >

    <input type="text" id="street" name="street" placeholder="Street" required>
    <input type="text" id="floor" name="floor" placeholder="Floor" pattern="[0-9]+" required>
       <div class="menu">
          <h2>Menu</h2>
          <div class="menu-item" data-item="Grilled Salmon" data-price="15.99">
            <h3>Grilled Salmon</h3>
            <p>
              Fresh salmon grilled to perfection, served with steamed vegetables
              and rice.
            </p>
            <label for="quantity-salmon">Quantity:</label>
            <input
              type="number"
              id="quantity-salmon"
              name="quantity-salmon"
              value="1"
              min="1"
            />
            <label>
              <input type="checkbox" name="options-salmon" value="No Cheese" />
              No Cheese
            </label>
            <label>
              <input type="checkbox" name="options-salmon" value="No Spice" />
              No Spice
            </label>
            <button class="add-to-cart" data-item="Grilled Salmon">
              Add to Cart
            </button>
          </div>

          <div
            class="menu-item"
            data-item="Margherita Pizza"
            data-price="12.99"
          >
            <h3>Margherita Pizza</h3>
            <p>
              Traditional Italian pizza topped with tomatoes, fresh mozzarella,
              and basil.
            </p>
            <label for="quantity-pizza">Quantity:</label>
            <input
              type="number"
              id="quantity-pizza"
              name="quantity-pizza"
              value="1"
              min="1"
            />
            <label>
              <input type="checkbox" name="options-pizza" value="No Basil" /> No
              Basil
            </label>
            <button class="add-to-cart" data-item="Margherita Pizza">
              Add to Cart
            </button>
          </div>
        </div>

        <div class="cart">
          <h2>Cart</h2>
          <ul class="cart-items" id="items">
          </ul>
          <p>Total: <span class="total" id="total-price">$0.00</span></p>
          <button type="submit" class="checkout" id="checkoutbutton">Checkout</button>
          <span class="input-requirements" style="font-size: 12px; color: #666;">Deliveries Available between 9:00 AM and 9:00 PM</span>

          <script>

    </script>
        </div>
      </form>
    </div>

    <script src="delivery.js"></script>
    <script>
      function getLocation() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(showPosition, showError);
        } else {
          alert("Geolocation is not supported by this browser.");
        }
      }

      function showPosition(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        document.getElementById("latitude").textContent = latitude;
    document.getElementById("longitude").textContent = longitude;

        calculateEstimatedTime(latitude,longitude);
        var mapLink =
          "https://www.google.com/maps?q=" + latitude + "," + longitude;
        document.getElementById("mapLink").innerHTML =
          "<a href='" + mapLink + "' target='_blank'>View Map</a>";
      }

      function showError(error) {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            alert("User denied the request for Geolocation.");
            break;
          case error.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
          case error.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
          case error.UNKNOWN_ERROR:
            alert("An unknown error occurred.");
            break;
        }
      }
      function calculateEstimatedTime(latitude, longitude) {

    var restaurantLat = 33.857392;
    var restaurantLng = 35.518993;
    var customerLat = latitude;
    var customerLng = longitude;
    var R = 6371;
    var dLat = deg2rad(customerLat - restaurantLat);
    var dLon = deg2rad(customerLng - restaurantLng);
    var a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(restaurantLat)) * Math.cos(deg2rad(customerLat)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var distance = R * c; 
    var Speed = 30;
    var estimatedTimeHours = (distance / Speed);
    var estimatedTimeMinutes = Math.round(estimatedTimeHours * 60)+35;
    var estimatedTime = "Estimated time: " + estimatedTimeMinutes + " minutes";
    alert(estimatedTime);
}

function deg2rad(deg) {
    return deg * (Math.PI / 180);
}
    </script>
  </body>
</html>
<div class="header">

<div class="top-left-buttons">
<?php
if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
    echo '<button id="logout-button" class="logout-button"><a href="logout.php">Logout</a></button>';
    echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
} else {
    echo '<button id="signin-button" class="signin-button"><a href="test.php">Sign</a></button>';
    echo '<button id="login-button" class="login-button"><a href="LogIn2.php">Login</a></button>';
    echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
}
?>
</div>

  <ul class="navbar">
    <li><a href="index.php">Home</a></li>
    <li><a href="reservation.php">Reservations</a></li>
    <li><a href="menu.php">Menu</a></li>
    <li><a href="delivery.php">Delivery</a></li>
  </ul>
</div>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartItemsList = document.querySelector('.cart-items');
    const totalSpan = document.querySelector('.total');
    const deliveryForm = document.getElementById('delivery-form');

    let total = 0;

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();

            const menuItem = button.parentElement;
            const itemName = menuItem.dataset.item;
            const itemPrice = parseFloat(menuItem.dataset.price);
            const quantityInput = menuItem.querySelector('input[type="number"]');
            const quantity = parseInt(quantityInput.value);
            const options = menuItem.querySelectorAll('input[type="checkbox"]:checked');
            let itemOptions = '';

            options.forEach(option => {
                itemOptions += ` (${option.value})`;
            });

            for (let i = 0; i < quantity; i++) {
                const cartItem = document.createElement('li');
                cartItem.textContent = `${itemName}${itemOptions}: $${itemPrice.toFixed(2)}`;
                cartItemsList.appendChild(cartItem);

                total += itemPrice;
                totalSpan.textContent = `$${total.toFixed(2)}`;
            }
        });
    });

deliveryForm.addEventListener('submit', function(event) {
    event.preventDefault();
    var currentHour = new Date().getHours();
        if (currentHour >= 21 || currentHour <= 9) {
            document.getElementById("checkoutButton").disabled = true;
        }
    var mapLink = document.getElementById('mapLink').textContent.trim();
    if (!mapLink) {
        alert('Please submit your address');
        return;
    }
    var cartItems = document.querySelectorAll('.cart-items li');
    if (cartItems.length === 0) {
        alert('Please add items to your cart before proceeding to checkout.');
        return;
    }
    
    var latitude = parseFloat(document.getElementById("latitude").textContent);
    var longitude = parseFloat(document.getElementById("longitude").textContent);
    var totalPrice = parseFloat(document.getElementById("total-price").textContent.replace('$', ''));
    var items = [];
    cartItems.forEach(function(item) {
        var itemText = item.textContent;
        var itemName = itemText.substring(0, itemText.indexOf(':'));
        var itemPrice = parseFloat(itemText.substring(itemText.indexOf('$') + 1));
        items.push({ name: itemName, price: itemPrice });
    });

    var formData = new FormData(deliveryForm);
    formData.append('latitude', latitude);
    formData.append('longitude', longitude);
    formData.append('total-price', totalPrice);
    formData.append('items', items);   formData.append('items', JSON.stringify(items));
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'AddDelivery.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
     
            cartItemsList.innerHTML = '';
            total = 0;
            totalSpan.textContent = '$0.00';
        } 
    };
    xhr.onerror = function() {
        alert('Request failed');
    };
    xhr.send(formData); 
    window.location.href = "GetDelivery.php";
});

  });
</script>
