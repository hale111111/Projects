<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: Admin.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "spark";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selected_date = isset($_GET['date']) ? $_GET['date'] : null;
$selected_month = isset($_GET['month']) ? $_GET['month'] : null;
$selected_year = isset($_GET['year']) ? $_GET['year'] : null;

if ($selected_date) {
    $sql = "SELECT * FROM data WHERE day = '$selected_date'";
} elseif ($selected_month) {
    $sql = "SELECT * FROM data WHERE DATE_FORMAT(day, '%Y-%m') = '$selected_month'";
} elseif ($selected_year) {
    $sql = "SELECT * FROM data WHERE YEAR(day) = '$selected_year'";
} else {
    $sql = "SELECT * FROM data"; 
}

$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }   
}

$total_records = count($data);
if ($total_records > 0) {
    $male_count = 0;
    $female_count = 0;
    $emotions = [];
    $total_age = 0;

    foreach ($data as $row) {
        if ($row['gender'] == 'Male') {
            $male_count++;
        } else {
            $female_count++;
        }

        $total_age += $row['age'];

        if (isset($emotions[$row['emotion']])) {
            $emotions[$row['emotion']]++;
        } else {
            $emotions[$row['emotion']] = 1;
        }
    }

    $male_percentage = ($male_count / $total_records) * 100;
    $female_percentage = ($female_count / $total_records) * 100;
    $average_age = $total_age / $total_records;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="fetch-data.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <h2>Data for <?php echo htmlspecialchars($selected_date ? $selected_date : ($selected_month ? $selected_month : ($selected_year ? $selected_year : "All Records"))); ?></h2>
        <?php if ($total_records > 0): ?>
            <div class="statistics-container">
                <div class="statistics-box">
                    <h3>Gender Distribution</h3>
                    <p>Male: <?php echo number_format($male_percentage, 2); ?>%</p>
                    <p>Female: <?php echo number_format($female_percentage, 2); ?>%</p>
                </div>
                <div class="statistics-box">
                    <h3>Emotion Distribution</h3>
                    <?php foreach ($emotions as $emotion => $count): ?>
                        <p><?php echo htmlspecialchars($emotion); ?>: <?php echo number_format(($count / $total_records) * 100, 2); ?>%</p>
                    <?php endforeach; ?>
                </div>
                <div class="statistics-box">
                    <h3>Average Age</h3>
                    <p><?php echo number_format($average_age, 2); ?></p>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="genderChart"></canvas>
                <canvas id="emotionChart"></canvas>
            </div>
            <table>
                <tr>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Emotion</th>
                    <th>Predicted Music</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>
                <?php foreach ($data as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['gender']); ?></td>
                    <td><?php echo htmlspecialchars($row['age']); ?></td>
                    <td><?php echo htmlspecialchars($row['emotion']); ?></td>
                    <td><?php echo htmlspecialchars($row['predicted_music']); ?></td>
                    <td><?php echo htmlspecialchars($row['day']); ?></td>
                    <td><?php echo htmlspecialchars($row['time']); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>

       
        <?php else: ?>
            <p>No data found for the selected date.</p>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const genderData = {
                labels: ['Male', 'Female'],
                datasets: [{
                    label: 'Gender Distribution (%)',
                    data: [<?php echo number_format($male_percentage, 2); ?>, <?php echo number_format($female_percentage, 2); ?>],
                    backgroundColor: ['#36A2EB', '#FF6384']
                }]
            };

            const genderConfig = {
                type: 'pie',
                data: genderData,
            };

            new Chart(
                document.getElementById('genderChart'),
                genderConfig
            );

            const emotionLabels = <?php echo json_encode(array_keys($emotions)); ?>;
            const emotionData = <?php echo json_encode(array_values($emotions)); ?>;
            const emotionPercentages = emotionData.map(value => (value / <?php echo $total_records; ?>) * 100);

            const emotionChartData = {
                labels: emotionLabels,
                datasets: [{
                    label: 'Emotion Distribution (%)',
                    data: emotionPercentages,
                    backgroundColor: emotionLabels.map(() => '#' + Math.floor(Math.random()*16777215).toString(16))
                }]
            };

            const emotionChartConfig = {
                type: 'bar',
                data: emotionChartData,
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100
                        }
                    }
                }
            };

            new Chart(
                document.getElementById('emotionChart'),
                emotionChartConfig
            );
        });
    </script>
</body>
</html>
