from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, IntegerType
import requests
import logging


logging.basicConfig(level=logging.INFO)

spark = SparkSession.builder \
    .appName("KafkaStreaming") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0") \
    .getOrCreate()

schema = StructType() \
    .add("gender", StringType()) \
    .add("age", IntegerType()) \
    .add("emotion", StringType()) \
    .add("predicted_music", StringType())

kafka_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "face") \
    .load()

json_df = kafka_df.select(from_json(col("value").cast("string"), schema).alias("data")).select("data.*")

def send_to_server(batch_df, batch_id):
    happy_count = batch_df.filter(col("emotion") == "Happy").count()
    sad_count = batch_df.filter(col("emotion") == "Sad").count()
    angry_count = batch_df.filter(col("emotion") == "Angry").count()
    neutral_count = batch_df.filter(col("emotion") == "Neutral").count()
    fear_count = batch_df.filter(col("emotion") == "Fearful").count()
    surprise_count = batch_df.filter(col("emotion") == "Surprised").count()
    disgust_count = batch_df.filter(col("emotion") == "Disgusted").count()

    logging.info(f"Batch {batch_id}: Happy count = {happy_count}, Sad count = {sad_count} , Angry count = {angry_count} , Neutral count = {neutral_count}, Fearful count = {fear_count}, Surprised count = {surprise_count}, Disgusted count = {disgust_count}")
    emotion_counts = {"happy": happy_count, "sad": sad_count, "angry": angry_count, "neutral": neutral_count, "fear": fear_count, "surprise": surprise_count, "disgust": disgust_count}

    try:
        response = requests.post("http://localhost:5000/emotion_count.php", json=emotion_counts)
        response.raise_for_status()
        logging.info(f"Successfully sent data to server: {emotion_counts}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to send data to server: {e}")

query = json_df.writeStream \
    .outputMode("append") \
    .foreachBatch(send_to_server) \
    .option("checkpointLocation", r"C:\emotion_count") \
    .trigger(processingTime="10 seconds") \
    .start()

query.awaitTermination()
