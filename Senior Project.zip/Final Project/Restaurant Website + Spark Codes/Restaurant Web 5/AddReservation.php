<?php
session_start();

$servername = "localhost";
$username = "root"; 
$password = "h1234"; 
$dbname = "restaurant"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $conn->real_escape_string($_POST['name']);
$date = $_POST['date'];
$time = $_POST['time'];
$guests = $conn->real_escape_string($_POST['guests']);
$table_type = $_POST['table'];
$id =session_id(); 
$email = $_SESSION['email'];

$sql = "INSERT INTO reservations(reservation_id,user_id, name, date, time, guests, table_type)
        VALUES ('$id','$email','$name', '$date', '$time', '$guests', '$table_type')";

if ($conn->query($sql) === TRUE) {
    header("Location: GetReservation.php");
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
