<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: Admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }
        .wrapper {
            display: flex;
            gap: 20px;
        }
        .container {
            text-align: center;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h1 {
            font-size: 24px;
            color: #333;
        }
        .data {
            margin: 20px 0;
        }
        .data p {
            font-size: 18px;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <h1>Gender Count Dashboard</h1>
            <div class="data" id="data">
            </div>
        </div>
        <div class="container">
            <h1>Emotion Count Dashboard</h1>
            <div class="data_emotion" id="data_emotion">
            </div>
        </div>
        <div class="container">
            <h1>Average Age Dashboard</h1>
            <div class="data_age" id="data_age">
            </div>
        </div>
        <div class="container">
            <h1>Music Dashboard</h1>
            <div class="data_music" id="data_music">
            </div>
        </div>
    </div>
    <script>
        function fetchData() {
            fetch('gender_count_get.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('data').innerHTML = `
                        <p>Male count: ${data.male_count}</p>
                        <p>Female count: ${data.female_count}</p>
                        <p>Timestamp: ${data.created_at}</p>
                    `;
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        function fetchData_emotion() {
            fetch('emotion_count_get.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('data_emotion').innerHTML = `
                        <p>happy count: ${data.happy_count}</p>
                        <p>sad count: ${data.sad_count}</p>
                         <p>angry count: ${data.angry_count}</p>
                        <p>neutral count: ${data.neutral_count}</p>
                         <p>fear count: ${data.fear_count}</p>
                        <p>disgust count: ${data.disgust_count}</p>
                         <p>surprise count: ${data.surprise_count}</p>
                        <p>Timestamp: ${data.created_at}</p>
                    `;
                })
                .catch(error => console.error('Error fetching data:', error));
        }
        function fetchData_age() {
            fetch('age_average_get.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('data_age').innerHTML = `
                        <p>Average age: ${data.average_age}</p>
                        <p>Timestamp: ${data.created_at}</p>
                    `;
                })
                .catch(error => console.error('Error fetching data:', error));
        }
        function fetchData_music() {
            fetch('music_count_get.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('data_music').innerHTML = `
                        <p>Chosen music: ${data.chosen_music}</p>
                        <p>Timestamp: ${data.created_at}</p>
                    `;
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        setInterval(fetchData, 1000);
        setInterval(fetchData_emotion, 1000);
        setInterval(fetchData_age, 1000);
        setInterval(fetchData_music, 1000);

        fetchData();
        fetchData_emotion();
        fetchData_age();
        fetchData_music();

    </script>
</body>
</html>
