<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "h1234"; 
$dbname = "restaurant"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['email'];
$today = date("Y-m-d");

$sql = "SELECT * FROM reservations WHERE user_id = '$user_id' AND date >= '$today'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<div style='font-family: Arial, sans-serif;'>";
    while ($row = $result->fetch_assoc()) {
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>";
        echo "<strong>Name:</strong> " . $row["name"] . "<br>";
        echo "<strong>Date:</strong> " . $row["date"] . "<br>";
        echo "<strong>Time:</strong> " . $row["time"] . "<br>";
        echo "<strong>Number of Guests:</strong> " . $row["guests"] . "<br>";
        echo "<strong>Table Type:</strong> " . $row["table_type"] . "<br>";
        echo "</div>";
    }
    echo "</div>";
} else {
    echo "No reservations found.";
}

$conn->close();
?>
