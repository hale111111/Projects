<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .order-details {
            max-width: 600px;
            margin: 0 auto;
            background-color: #f9f9f9;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        .order-details-item {
            margin-bottom: 10px;
        }
        .order-details-item label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="order-details">
        <h1>Order Details</h1>
        <?php
        session_start();

        $servername = "localhost";
        $username = "root"; 
        $password = "h1234"; 
        $dbname = "restaurant"; 

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $email = $_SESSION['email'];
        $date=date("Y-m-d");

        $sql = "SELECT email, date, street, floor, items, total_price FROM `order` WHERE email = '$email' and date='$date' ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="order-details-item">
                    <label>Email:</label>
                    <span><?php echo $row["email"]; ?></span>
                </div>
                <div class="order-details-item">
                    <label>Date:</label>
                    <span><?php echo $row["date"]; ?></span>
                </div>
                <div class="order-details-item">
                    <label>Street:</label>
                    <span><?php echo $row["street"]; ?></span>
                </div>
                <div class="order-details-item">
                    <label>Floor:</label>
                    <span><?php echo $row["floor"]; ?></span>
                </div>
                <div class="order-details-item">
                    <label>Items:</label>
                    <span><?php echo $row["items"]; ?></span>
                </div>
                <div class="order-details-item">
                    <label>Total Price:</label>
                    <span><?php echo $row["total_price"]; ?></span>
                </div>
                <?php
            }
        } else {
            echo "<p>No orders found for this email.</p>";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
