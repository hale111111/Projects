<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: Admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Links</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        h1 {
            color: #333;
        }
        .links {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .link {
            margin: 10px 0;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>Welcome to Our Service</h1>
    <div class="links">
        <a href="admin-reservation.php" class="link">Reservations</a>
        <a href="admin-delivery.php" class="link">Delivery</a>
        <a href="admin-dashboard.php" class="link">Dashboard</a>
    </div>
</body>
</html>
