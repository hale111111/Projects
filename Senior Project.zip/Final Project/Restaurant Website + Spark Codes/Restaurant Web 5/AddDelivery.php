<?php
session_start();

$servername = "localhost";
$username = "root"; 
$password = "h1234"; 
$dbname = "restaurant"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$street = $_POST['street'];
$floor = $_POST['floor'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$totalPrice = $_POST['total-price'];
$items_json = $_POST['items'] ?? ''; 
$email = $_SESSION['email'];
$date=date("Y-m-d");

$items_array = json_decode($items_json, true); 

$item_names = [];

foreach ($items_array as $item) {
    $item_name = $item['name']; 
    if (isset($item['options']) && !empty($item['options'])) {
        $item_name .= '(' . implode(',', $item['options']) . ')';
    }
    $item_names[] = $item_name;
}
$items_display = implode(';', $item_names);

$street = mysqli_real_escape_string($conn, $street);
$floor = mysqli_real_escape_string($conn, $floor);
$latitude = mysqli_real_escape_string($conn, $latitude);
$longitude = mysqli_real_escape_string($conn, $longitude);
$totalPrice = mysqli_real_escape_string($conn, $totalPrice);

$sql = "INSERT INTO `order` (email,date,latitude, longitude, street, floor, items, total_price) 
        VALUES ('$email','$date','$latitude', '$longitude', '$street', '$floor', '$items_display', '$totalPrice')";

if ($conn->query($sql) === TRUE) {
 
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
