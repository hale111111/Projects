<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$verificationCode = $_POST['verification_code'];

if ($verificationCode === $_SESSION['verification_code']) {
    $firstname = $_SESSION['firstname'];
    $middlename = $_SESSION['middlename'];
    $lastname = $_SESSION['lastname'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $phone = $_SESSION['phone'];

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (firstname, middlename, lastname, email, password, phone) VALUES ('$firstname', '$middlename', '$lastname', '$email', '$hashedPassword', '$phone')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }

    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Incorrect verification code']);
}
?>
