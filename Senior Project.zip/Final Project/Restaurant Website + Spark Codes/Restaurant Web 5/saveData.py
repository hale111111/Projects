from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, current_timestamp, date_format
from pyspark.sql.types import StructType, StringType, IntegerType

spark = SparkSession.builder \
    .appName("KafkaStreaming") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0") \
    .getOrCreate()

schema = StructType() \
    .add("gender", StringType()) \
    .add("age", IntegerType()) \
    .add("emotion", StringType()) \
    .add("predicted_music", StringType())

kafka_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "face") \
    .load()

parsed_df = kafka_df.selectExpr("CAST(value AS STRING)") \
    .select(from_json("value", schema).alias("data")) \
    .select("data.*")

parsed_df = parsed_df.withColumn("timestamp", current_timestamp())

parsed_df = parsed_df.withWatermark("timestamp", "10 minutes")

parsed_df = parsed_df.withColumn("day", date_format("timestamp", "yyyy-MM-dd"))
parsed_df = parsed_df.withColumn("time", date_format("timestamp", "HH:mm:ss"))

output_path = r"C:\spark-data"

def write_data_to_output(df, batch_id):
    df.coalesce(1).write.json(output_path + "/batch", mode="append")

spark_query = parsed_df.writeStream \
    .foreachBatch(write_data_to_output) \
    .outputMode("append") \
    .start()

spark.streams.awaitAnyTermination()



