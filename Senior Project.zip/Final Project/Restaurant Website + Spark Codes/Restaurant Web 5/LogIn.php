<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "h1234"; 
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $conn->real_escape_string($_POST['email']);
$password = $conn->real_escape_string($_POST['password']);

$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    $hashedPasswordFromDatabase = $row['password'];

    if (password_verify($password, $hashedPasswordFromDatabase)) {
        $_SESSION['loggedIn'] = true;
        $_SESSION['email']=$email;
        header("Location: index.php?error=" . urlencode('success'));
        exit;
    } else {
        $_SESSION['loggedIn'] = false;
        header("Location: LogIn2.php?error=" . urlencode('failure'));
        
        exit;
    }
} else {
    $_SESSION['loggedIn'] = false;
    header("Location: LogIn2.php?error=" . urlencode('failure'));
    exit;
}

$conn->close();

?>
