<?php

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "spark";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    $chosen_music = $data['chosen_music'];
 
    $sql = "INSERT INTO music (chosen_music) VALUES ('$chosen_music')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "No data received";
}

$conn->close();
?>