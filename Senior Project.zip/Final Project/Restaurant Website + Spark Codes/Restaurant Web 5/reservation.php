<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hale Restaurant</title>
    <link rel="stylesheet" href="reservation.css" />

  </head>
  <body>
  <script>
window.onload = function() {
    <?php
    session_start();
    if(!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
        echo 'document.getElementById("overlay").style.display = "block";';
    }
    ?>
    
}
</script>

<div id="overlay" style="display: none;">
    <div id="popup-form">
        <form action="Sign.html" method="post">
            <h2>Please Sign In or Log In</h2>
            <input type="submit" value="Sign In">
        </form>
        <form action="LogIn2.php">
            <input type="submit" value="Log In">
        </form>
    </div>
</div>
    <section id="reservation">
      <div class="container">
        <h2>Make a Reservation</h2>
        <a href="GetReservation.php"><button class="my-reservations-button" >My Reservations</button></a>
        <form method="post" action="AddReservation.php"  >
          <label for="name">Name:</label>
          <input type="text" id="name" name="name" pattern="[A-Za-z ]+" required />
        
          <label for="date">Date:</label>
          <input type="date" id="date" name="date" min="<?php echo date('Y-m-d'); ?>" required />

          <label for="time">Time:</label>
<input type="time" id="time" name="time" min="09:00" max="22:00" required />
<span class="input-requirements">Time must be between 9:00 AM and 10:00 PM</span>

<label for="guests">Number of Guests:</label>
<input type="number" id="guests" name="guests" min="1" max="20" required />
<span class="input-requirements">Number of guests must be between 1 and 20</span>

          <label for="table">Table Type:</label>
          <select id="table" name="table">
            <option value="indoor">Indoor</option>
            <option value="outdoor">Outdoor</option>
            <option value="private">Private Room</option>
          </select>

          <input type="submit" value="Submit" />
        </form>
      </div>
    </section>
  </body>
</html>
<script>
function submitForm() {
    alert("Reservation is booked");
}
document.addEventListener("DOMContentLoaded", function() {
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var minDate = tomorrow.toISOString().split("T")[0];
    document.getElementById("date").setAttribute("min", minDate);
});

</script>

<div class="header">

<div class="top-left-buttons">
<?php
if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
    echo '<button id="logout-button" class="logout-button"><a href="logout.php">Logout</a></button>';
    echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
} else {
    echo '<button id="signin-button" class="signin-button"><a href="test.php">Sign</a></button>';
    echo '<button id="login-button" class="login-button"><a href="LogIn2.php">Login</a></button>';
    echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
}
?>
</div>

  <ul class="navbar">
    <li><a href="index.php">Home</a></li>
    <li><a href="reservation.php">Reservations</a></li>
    <li><a href="menu.php">Menu</a></li>
    <li><a href="delivery.php">Delivery</a></li>
  </ul>
</div>