<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restaurant Menu</title>
    <link rel="stylesheet" href="menu.css" />
    <?php
session_start();
?>

<div class="header">
  <div class="top-left-buttons">
  <?php
  if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
      echo '<button id="logout-button" class="logout-button"><a href="logout.php">Logout</a></button>';
      echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
  } else {
      echo '<button id="signin-button" class="signin-button"><a href="test.php">Sign</a></button>';
      echo '<button id="login-button" class="login-button"><a href="LogIn2.php">Login</a></button>';
      echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
  }
  ?>
  </div>

  <ul class="navbar">
    <li><a href="index.php">Home</a></li>
    <li><a href="reservation.php">Reservations</a></li>
    <li><a href="menu.php">Menu</a></li>
    <li><a href="delivery.php">Delivery</a></li>
  </ul>
</div>

  </head>
  <body>
    <div class="container">
      <h1>Menu</h1>

      <h2>Breakfast</h2>
      <div class="menu-item">
        <img
          src="https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F43%2F2022%2F02%2F17%2F21014-Good-old-Fashioned-Pancakes-mfs_002.jpg&q=60&c=sc&poi=auto&orient=true&h=512.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Classic Pancakes</div>
          <div class="menu-item-description">
            Fluffy pancakes served with maple syrup and butter.
          </div>
        </div>
        <div class="menu-item-price">$7.99</div>
      </div>

      <div class="menu-item">
        <img
          src="https://www.allrecipes.com/thmb/CjrK2YaITW3sL1SdTtJIXDg-stc=/0x512/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/17205-eggs-benedict-DDMFS-4x3-a0042d5ae1da485fac3f468654187db0.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Eggs Benedict</div>
          <div class="menu-item-description">
            Poached eggs and Canadian bacon on English muffins, topped with
            hollandaise sauce.
          </div>
        </div>
        <div class="menu-item-price">$9.99</div>
      </div>

      <h2>Dinner</h2>
      <div class="menu-item">
        <img
          src="https://www.cookingclassy.com/wp-content/uploads/2022/07/grilled-steak-15-768x1152.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Grilled Steak</div>
          <div class="menu-item-description">
            Tender grilled steak cooked to your preference, served with mashed
            potatoes and grilled vegetables.
          </div>
        </div>
        <div class="menu-item-price">$19.99</div>
      </div>

      <div class="menu-item">
        <img
          src="https://assets.epicurious.com/photos/5988e3458e3ab375fe3c0caf/1:1/w_1920,c_limit/How-to-Make-Chicken-Alfredo-Pasta-hero-02082017.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Chicken Alfredo</div>
          <div class="menu-item-description">
            Creamy fettuccine Alfredo with grilled chicken and garlic bread.
          </div>
        </div>
        <div class="menu-item-price">$15.99</div>
      </div>

      <h2>Seafood</h2>
      <div class="menu-item">
        <img
          src="https://recipes.net/wp-content/uploads/2021/09/shrimp-scampi-olive-garden-recipe-copycat.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Shrimp Scampi</div>
          <div class="menu-item-description">
            Sauteed shrimp in a garlic and butter sauce, served over linguine.
          </div>
        </div>
        <div class="menu-item-price">$17.99</div>
      </div>

      <h2>Dessert</h2>
      <div class="menu-item">
        <img
          src="https://www.foodnetwork.com/content/dam/images/food/fullset/2014/2/19/1/WU0701H_Molten-Chocolate-Cakes_s4x3.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Chocolate Lava Cake</div>
          <div class="menu-item-description">
            Warm chocolate cake with a gooey chocolate center, served with
            vanilla ice cream.
          </div>
        </div>
        <div class="menu-item-price">$8.99</div>
      </div>

      <h2>Drinks</h2>
      <div class="menu-item">
        <img
          src="https://www.bhg.com/thmb/RuIXqyj_sGoJwZSs8DpKLF2Qa2g=/1244x0/filters:no_upscale():strip_icc()/diy-mojito-RU186788-1-b3184133555544bbae783b67881d1400.jpg"
          alt="Menu Item"
        />
        <div class="menu-item-info">
          <div class="menu-item-name">Mojito</div>
          <div class="menu-item-description">
            Refreshing cocktail made with rum, mint, lime, sugar, and soda
            water.
          </div>
        </div>
        <div class="menu-item-price">$10.99</div>
      </div>

    </div>
  </body>
</html>
