<?php

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = mysqli_real_escape_string($conn, $_POST['email']);
$date = mysqli_real_escape_string($conn, $_POST['date']);
$street = mysqli_real_escape_string($conn, $_POST['street']);
$items = mysqli_real_escape_string($conn, $_POST['items']);
$total_price = mysqli_real_escape_string($conn, $_POST['total_price']);

$sql = "SELECT * FROM `order` WHERE 1=1";

if (!empty($email)) {
    $sql .= " AND email='$email'";
}
if (!empty($date)) {
    $sql .= " AND date='$date'";
}
if (!empty($street)) {
    $sql .= " AND street='$street'";
}
if (!empty($items)) {
    $sql .= " AND items LIKE '%$items%'";
}
if (!empty($total_price)) {
    $sql .= " AND total_price > '$total_price'";
}

$result = $conn->query($sql);

echo "<div class='container'>";
if ($result->num_rows > 0) {
    echo "<h1>Delivery Records</h1>";
    echo "<table>";
    echo "<tr><th>Email</th><th>Date</th><th>Street</th><th>Items</th><th>Total Price</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["email"]. "</td><td>" . $row["date"]. "</td><td>" . $row["street"]. "</td><td>" . $row["items"]. "</td><td>" . $row["total_price"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<h1>No results found</h1>";
}
echo "</div>";

$conn->close();
?>
 <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 800px;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
        }
        input, select {
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
    </style>
