<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign Up</title>
    <link rel="stylesheet" href="signin.css" />
  </head>
  <body>
    <div class="signup-container">
      <h2>Sign Up</h2>

      <?php
session_start();

if (isset($_GET['error'])) {
  $error = $_GET['error'];
  echo "<p style='color: red'>$error</p>";
  unset($_SESSION['error']);  

}
?>
      <form action="signin.php" method="post">
        
        <label for="firstname">First Name:</label>
        <input type="text" id="firstname" name="firstname" required />

        <label for="middlename">Middle Name:</label>
        <input type="text" id="middlename" name="middlename" />

        <label for="lastname">Last Name:</label>
        <input type="text" id="lastname" name="lastname" required />

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required />

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" pattern="^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$" required />
        <div class="password-requirements">Password must contain at least one letter, one number, one symbol, and be at least 6 characters long.</div>
        
        <label for="confirm_password">Confirm Password:</label>
        <input
          type="password"
          id="confirm_password"
          name="confirm_password"
          required
        />

        <label for="phone">Phone Number:</label>
        <input type="tel" id="phone" name="phone" required />

        <input type="submit" value="Sign Up" />
        
      </form>
    </div>
  </body>
</html>
