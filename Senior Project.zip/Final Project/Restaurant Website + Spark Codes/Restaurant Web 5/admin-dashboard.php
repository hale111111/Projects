<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: Admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin-dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <h2>Welcome to Admin Dashboard</h2>
        <p>You are successfully logged in.</p>
        <form id="dateForm" action="fetch-data.php" method="GET">
            <label for="date">Select Date:</label>
            <input type="date" id="date" name="date">
            <label for="month">Select Month:</label>
            <input type="month" id="month" name="month">
            <label for="year">Select Year:</label>
            <input type="number" id="year" name="year" min="2020" max="2100">
            <button type="submit">Fetch Data</button>
        </form>
        <div id="data-table">
        </div>
        <button onclick="window.location.href='Real_time_data.php'">Real Time Streaming</button>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('date');
            const monthInput = document.getElementById('month');
            const yearInput = document.getElementById('year');

            function disableOthers(selectedInput) {
                if (selectedInput === 'date') {
                    monthInput.value = '';
                    yearInput.value = '';
                    monthInput.disabled = true;
                    yearInput.disabled = true;
                } else if (selectedInput === 'month') {
                    dateInput.value = '';
                    yearInput.value = '';
                    dateInput.disabled = true;
                    yearInput.disabled = true;
                } else if (selectedInput === 'year') {
                    dateInput.value = '';
                    monthInput.value = '';
                    dateInput.disabled = true;
                    monthInput.disabled = true;
                }
            }

            dateInput.addEventListener('change', function() {
                if (dateInput.value) {
                    disableOthers('date');
                } else {
                    monthInput.disabled = false;
                    yearInput.disabled = false;
                }
            });

            monthInput.addEventListener('change', function() {
                if (monthInput.value) {
                    disableOthers('month');
                } else {
                    dateInput.disabled = false;
                    yearInput.disabled = false;
                }
            });

            yearInput.addEventListener('change', function() {
                if (yearInput.value) {
                    disableOthers('year');
                } else {
                    dateInput.disabled = false;
                    monthInput.disabled = false;
                }
            });
        });
    </script>
</body>
</html>
