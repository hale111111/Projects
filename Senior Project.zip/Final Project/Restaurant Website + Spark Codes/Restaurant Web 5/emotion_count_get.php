<?php

header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "spark";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT happy_count,sad_count,angry_count,neutral_count,fear_count,disgust_count,surprise_count, created_at FROM emotion_counts ORDER BY created_at DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    $data = ["happy_count" => 0, "sad_count" => 0, "angry_count" => 0,"neutral_count" => 0,"fear_count" => 0,"disgust_count" => 0,"surprise_count" => 0,"created_at" => "N/A"];
}

$conn->close();

echo json_encode($data);
?>