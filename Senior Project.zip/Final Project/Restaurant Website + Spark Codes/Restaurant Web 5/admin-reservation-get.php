<?php
$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$date = mysqli_real_escape_string($conn, $_POST['date']);
$time = mysqli_real_escape_string($conn, $_POST['time']);
$guests = mysqli_real_escape_string($conn, $_POST['guests']);
$table_type = mysqli_real_escape_string($conn, $_POST['table_type']);

$sql = "SELECT * FROM reservations WHERE 1=1";


if (!empty($user_id)) {
    $sql .= " AND user_id='$user_id'";
}
if (!empty($name)) {
    $sql .= " AND name='$name'";
}
if (!empty($date)) {
    $sql .= " AND date='$date'";
}
if (!empty($time)) {
    $sql .= " AND time='$time'";
}
if (!empty($guests)) {
    $sql .= " AND guests='$guests'";
}
if (!empty($table_type)) {
    $sql .= " AND table_type='$table_type'";
}

$result = $conn->query($sql);

echo "<div class='container'>";
if ($result->num_rows > 0) {
    echo "<h1>Reservations</h1>";
    echo "<table>";
    echo "</tr><th>User ID</th><th>Name</th><th>Date</th><th>Time</th><th>Guests</th><th>Table Type</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "</tr><td>" . $row["user_id"]. "</td><td>" . $row["name"]. "</td><td>" . $row["date"]. "</td><td>" . $row["time"]. "</td><td>" . $row["guests"]. "</td><td>" . $row["table_type"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<h1>No results found</h1>";
}
echo "</div>";

$conn->close();
?>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
        }
        input, select {
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
    </style>