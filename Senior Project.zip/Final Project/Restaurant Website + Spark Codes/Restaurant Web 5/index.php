<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hale Restaurant-HomePage</title>
    <link rel="stylesheet" href="index.css" />
    <div class="header">

    <?php

session_start();
?>

<div class="top-left-buttons">
    <?php

    if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
 
        echo '<button id="logout-button" class="logout-button"><a href="logout.php">Logout</a></button>';
        echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
    } else {
        echo '<button id="signin-button" class="signin-button"><a href="test.php">Sign</a></button>';
        echo '<button id="login-button" class="login-button"><a href="LogIn2.php">Login</a></button>';
        echo '<button id="admin-button" class="admin-button"><a href="Admin.php">Admin</a></button>';
        
    }
    ?>
</div>

      <ul class="navbar">
        <li><a href="index.php">Home</a></li>
        <li><a href="reservation.php">Reservations</a></li>
        <li><a href="menu.php">Menu</a></li>
        <li><a href="delivery.php">Delivery</a></li>
      </ul>
    </div>
  </head>
  <body>
    <div class="container3">
    <p class="title">Hale Restaurant</p>

    <div class="slideshow-container">
      <div class="mySlides fade">
        <img
          src="https://images.rawpixel.com/image_1300/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L3Vwd2s2MTY2MTU3Ny13aWtpbWVkaWEtaW1hZ2Uta293YXBlZWouanBn.jpg
        3000w"
          style="width: 100%"
        />
      </div>

      <div class="mySlides fade">
        <img
          src="https://images.rawpixel.com/image_1300/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvYTAxOS1qYWt1YmstMTkxNy1rb3JlYW4tY3Vpc2luZV8xNS5qcGc.jpg 3000w"
          style="width: 100%"
        />
      </div>

      <div class="mySlides fade">
        <img
          src="https://images.rawpixel.com/image_1300/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvcHg1MDczNzYtaW1hZ2Uta3d2dmcwdmMuanBn.jpg 3000w"
          style="width: 100%"
        />
      </div>

      <div class="mySlides fade">
        <img
          src="https://images.rawpixel.com/image_1300/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L2EwMDkta2Fib29tcGljcy0wMDEuanBn.jpg 3000w"
          style="width: 100%"
        />
      </div>
    </div>

    <script src="Home.js"></script>
  </div>
    <section id="about">
      <div class="container2">
        <div class="content">
          <div class="text">
    <h1>About US</h1>
    <p>Welcome to Hale Restaurant, where culinary excellence meets unforgettable dining experiences. Nestled in the heart of Beirut, our restaurant is a haven for food enthusiasts seeking authentic flavors and impeccable service.

      At Hale Restaurant, we pride ourselves on crafting dishes that tantalize the taste buds and warm the soul. Our talented chefs draw inspiration from local ingredients and global culinary traditions to create a diverse menu that caters to every palate. From classic comfort food to innovative gastronomic creations, each dish is a culinary masterpiece designed to delight and satisfy.
      
      But our commitment to excellence extends beyond the kitchen. We believe that dining is an experience to be savored, and our warm and inviting ambiance reflects this philosophy. Whether you're celebrating a special occasion with loved ones or enjoying a casual meal with friends, our restaurant provides the perfect setting for memorable moments and cherished memories.
      
      At the heart of Hale Restaurant is a dedication to hospitality. Our attentive staff members are passionate about providing exceptional service and ensuring that every guest feels welcomed and valued. From the moment you step through our doors, you'll be greeted with genuine warmth and treated to a dining experience that goes beyond expectations.
      
      We invite you to join us at Hale Restaurant and embark on a culinary journey like no other. Whether you're a seasoned foodie or simply looking for a delicious meal in a welcoming atmosphere, we promise an unforgettable dining experience that will leave you coming back for more.
      
      Feel free to further personalize this text to match the unique identity and offerings of Hale Restaurant.</p>
    </div>
    <div class="image">
      <img class="img1" src="https://nationaltoday.com/wp-content/uploads/2021/07/shutterstock_1518533924-min-1200x834.jpg" alt="Restaurant Image">
    </div>
  </div>
    </div>
  </section>
      <footer>
      <div class="container">
        <div class="footer-info">
          <h3>Hale Restaurant</h3>
          <p>Address: 123 El Hamra, Beirut, Lebanon</p>
          <p>Phone: +1 234 567 890</p>
          <p>Email: HaleRestaurant@gmail.com</p>
        </div>
        <div class="social-media">
          <h3>Follow Us</h3>
          <ul>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">Instagram</a></li>
          </ul>
        </div>
      </div>
    </footer>
</html>
