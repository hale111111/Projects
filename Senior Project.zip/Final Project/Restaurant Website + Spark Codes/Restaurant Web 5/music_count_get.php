<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "h1234";
$dbname = "spark";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT chosen_music, created_at FROM music ORDER BY created_at DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    $data = ["chosen_music" => 0, "created_at" => "N/A"];
}

$conn->close();

echo json_encode($data);
?>
