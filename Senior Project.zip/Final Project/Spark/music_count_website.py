import json
import threading
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, count
from pyspark.sql.types import StructType, StringType, IntegerType
import requests
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("KafkaStreaming") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0") \
    .getOrCreate()

# Define the schema for the Kafka messages
schema = StructType() \
    .add("gender", StringType()) \
    .add("age", IntegerType()) \
    .add("emotion", StringType()) \
    .add("predicted_music", StringType())

# Read data from Kafka
kafka_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "face") \
    .load()

json_df = kafka_df.select(from_json(col("value").cast("string"), schema).alias("data")).select("data.*")

# Function to send the most frequent music to a web server
def send_to_server(batch_df, batch_id):
    # Group by predicted_music and count occurrences
    music_counts = batch_df.groupBy("predicted_music").count()

    # Find the music with the highest count
    most_frequent_music = music_counts.orderBy(col("count").desc()).first()

    if most_frequent_music:
        most_frequent_music_name = most_frequent_music["predicted_music"]
        most_frequent_music_count = most_frequent_music["count"]
        chosen_music_json = json.dumps(most_frequent_music)
        # Log the most frequent music
        logging.info(f"Batch {batch_id}: Most frequent music = {most_frequent_music_name}, Count = {most_frequent_music_count}")

        # Send the most frequent music to the web server
        data_music = {"chosen_music": most_frequent_music_name}
        try:
            response = requests.post("http://localhost:5000/music_count.php", json=data_music)
            response.raise_for_status()
            logging.info(f"Successfully sent data to server: {data_music}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Failed to send data to server: {e}")
    else:
        logging.info(f"Batch {batch_id}: No music data found.")

# Write the result to the web server using foreachBatch
query = json_df.writeStream \
    .outputMode("append") \
    .foreachBatch(send_to_server) \
    .option("checkpointLocation", r"C:\music_count") \
    .trigger(processingTime="10 seconds") \
    .start()

query.awaitTermination()
