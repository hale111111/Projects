import threading
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, IntegerType
import requests
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("KafkaStreaming") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0") \
    .getOrCreate()

# Define the schema for the Kafka messages
schema = StructType() \
    .add("gender", StringType()) \
    .add("age", IntegerType()) \
    .add("emotion", StringType()) \
    .add("predicted_music", StringType())

# Read data from Kafka
kafka_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "face") \
    .load()

json_df = kafka_df.select(from_json(col("value").cast("string"), schema).alias("data")).select("data.*")


# Function to send the gender counts to a web server
def send_to_server(batch_df, batch_id):
    # Filter and count the records for "Male" and "Female"
    male_count = batch_df.filter(col("gender") == "Male").count()
    female_count = batch_df.filter(col("gender") == "Female").count()

    # Log the counts
    logging.info(f"Batch {batch_id}: Male count = {male_count}, Female count = {female_count}")

    # Send the counts to the web server
    data = {"male": male_count, "female": female_count}
    try:
        response = requests.post("http://localhost:5000/gender_count.php", json=data)
        response.raise_for_status()
        logging.info(f"Successfully sent data to server: {data}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to send data to server: {e}")


# Write the result to the web server using foreachBatch
query = json_df.writeStream \
    .outputMode("append") \
    .foreachBatch(send_to_server) \
    .option("checkpointLocation", r"C:\gender_count") \
    .trigger(processingTime="10 seconds") \
    .start()

query.awaitTermination()