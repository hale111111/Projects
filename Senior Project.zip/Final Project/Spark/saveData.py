from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, avg, current_timestamp, date_format
from pyspark.sql.types import StructType, StringType, IntegerType

spark = SparkSession.builder \
    .appName("KafkaStreaming") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0") \
    .getOrCreate()

# Define the schema for the Kafka messages
schema = StructType() \
    .add("gender", StringType()) \
    .add("age", IntegerType()) \
    .add("emotion", StringType()) \
    .add("predicted_music", StringType())

# Read data from Kafka
kafka_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "face") \
    .load()

# Parse the value column from JSON to DataFrame columns
parsed_df = kafka_df.selectExpr("CAST(value AS STRING)") \
    .select(from_json("value", schema).alias("data")) \
    .select("data.*")

# Add a timestamp column to the data
parsed_df = parsed_df.withColumn("timestamp", current_timestamp())

# Add a watermark to handle late data
parsed_df = parsed_df.withWatermark("timestamp", "10 minutes")

# Extract day and time from the timestamp
parsed_df = parsed_df.withColumn("day", date_format("timestamp", "yyyy-MM-dd"))
parsed_df = parsed_df.withColumn("time", date_format("timestamp", "HH:mm:ss"))

# Define the output paths
output_path_age = r"C:\spark-data"

def write_avg_age_to_output(df, batch_id):
    df.coalesce(1).write.json(output_path_age + "/batch", mode="append")

# Define a query for average age aggregation
avg_age_query = parsed_df.writeStream \
    .foreachBatch(write_avg_age_to_output) \
    .outputMode("append") \
    .start()

spark.streams.awaitAnyTermination()
